/**
 * Created by mac on 2017/2/20.
 */
$(document).ready(function(){

    var oPurIndex = {
        init:function(){

        }
    }
    oPurIndex.init();
})